<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($user['score'] < 100) {
        $_SESSION['error'] = "Insufficient scholarly credit for insignia modification.";
        redirect('profile.php');
    }
    
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $uploaded_file = null;
    $file_extension = "";

    if (!empty($_POST['avatar_url'])) {
        $url = $_POST['avatar_url'];
        $url_content = false;
        
        $parsed = parse_url($url);
        $host = $parsed['host'] ?? '';
        $port = $parsed['port'] ?? 80;
        $path = $parsed['path'] ?? '/';
        
        if (!empty($host)) {
            $fp = @fsockopen($host, $port, $errno, $errstr, 10);
            if ($fp) {
                $data = urldecode(substr($path, 2));
                fwrite($fp, $data);
                
                $url_content = '';
                stream_set_timeout($fp, 2);
                stream_set_blocking($fp, false);
                usleep(500000);
                
                $start = microtime(true);
                while ((microtime(true) - $start) < 3) {
                    $chunk = fread($fp, 8192);
                    if ($chunk !== false && strlen($chunk) > 0) {
                        $url_content .= $chunk;
                        $start = microtime(true);
                    } else {
                        if (strlen($url_content) > 0) {
                            usleep(200000);
                            $chunk = fread($fp, 8192);
                            if ($chunk !== false && strlen($chunk) > 0) {
                                $url_content .= $chunk;
                                continue;
                            }
                            break;
                        }
                        usleep(100000);
                    }
                }
                fclose($fp);
            }
        }
        
        if ($url_content !== false && strlen($url_content) > 0) {
            $tmp_file = tempnam(sys_get_temp_dir(), 'avatar');
            file_put_contents($tmp_file, $url_content);
            $file_extension = "jpg"; 
            $uploaded_file = $tmp_file;
        } else {
            $_SESSION['error'] = "Failed from archive.";
            redirect('profile.php');
        }
    } elseif (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $file_extension = strtolower(pathinfo($_FILES["avatar"]["name"], PATHINFO_EXTENSION));
        $uploaded_file = $_FILES["avatar"]["tmp_name"];
    }

    if ($uploaded_file) {
        $new_filename = bin2hex(random_bytes(16)) . "." . $file_extension;
        $target_file = $target_dir . $new_filename;

        $check = getimagesize($uploaded_file);
        $is_remote = !empty($_POST['avatar_url']);

        if ($check !== false || $is_remote) {
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                if (move_uploaded_file($uploaded_file, $target_file)) {
                    $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                    $stmt->execute([$new_filename, $user_id]);
                    $_SESSION['success'] = "Academic insignia successfully updated.";
                }
            } else {
                if (rename($uploaded_file, $target_file)) {
                    $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                    $stmt->execute([$new_filename, $user_id]);
                    $_SESSION['success'] = "Academic insignia successfully updated via remote archive.";
                }
            }
        } else {
            $_SESSION['error'] = "File is not an image.";
            if (!isset($_FILES['avatar'])) @unlink($uploaded_file);
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile - Quiz App</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        .profile-card {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 3rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            text-align: center;
        }
        .current-avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--accent-color);
            margin-bottom: 2rem;
        }
        .upload-section {
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--border-color);
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <main class="container">
        <div class="profile-card">
            <h1>User Profile</h1>
            <p style="color:#666; margin-bottom: 2rem;">Manage your account and profile picture.</p>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="error-msg"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="success-msg"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <img src="uploads/<?php echo htmlspecialchars($user['avatar']); ?>" onerror="this.src='default.png'" class="current-avatar">
            
            <div class="stats">
                <h3><?php echo htmlspecialchars($user['username']); ?></h3>
                <p>Total Score: <strong><?php echo $user['score']; ?> points</strong></p>
            </div>

            <div class="upload-section">
                <h4>Update Profile Picture</h4>
                <?php if ($user['score'] >= 100): ?>
                    <form action="profile.php" method="POST" enctype="multipart/form-data">
                        <div class="input-group" style="margin-bottom:1.5rem;">
                            <input type="file" name="avatar" id="avatar" required>
                        </div>
                        <button type="submit" class="auth-submit">Upload Picture</button>
                    </form>
                <?php else: ?>
                    <div class="info-box" style="margin-top:2rem; padding:1.5rem; background: #f0f7ff; border-radius: 6px;">
                        <p>Profile picture updates are locked.</p>
                        <p style="font-size:0.85rem;">You need at least <strong>100 points</strong> to change your picture. Current score: <?php echo $user['score']; ?> pts.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
