<nav class="top-nav">
    <div class="logo">Quiz App</div>
    <div class="nav-links">
        <?php if (isLoggedIn()): ?>
            <a href="index.php">Quiz</a>
            <a href="leaderboard.php">Leaderboard</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>
</nav>
