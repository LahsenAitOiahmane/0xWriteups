<footer class="main-footer">
    <div class="container">
        <p>&copy; <?php echo date("Y"); ?> Quiz App. All rights reserved.</p>
    </div>
</footer>
