<?php
require_once 'config.php';

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question_id = (int)($_POST['question_id'] ?? 0);
    $answer = $_POST['answer'] ?? '';
    $user_id = $_SESSION['user_id'];
    
    session_write_close();

    $is_both_type = true; 
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM solved_questions WHERE user_id = ? AND question_id = ?");
    $stmt->execute([$user_id, $question_id]);
    $solved = $stmt->fetchColumn();

    if (!$solved) {
        usleep(200000); 

        $correct_answer = $_SESSION['correct_options'][$question_id] ?? '';

        if ($answer === $correct_answer) {
            $stmt = $pdo->prepare("UPDATE users SET score = score + 10 WHERE id = ?");
            $stmt->execute([$user_id]);

            $stmt = $pdo->prepare("INSERT INTO solved_questions (user_id, question_id) VALUES (?, ?)");
            $stmt->execute([$user_id, $question_id]);

            echo json_encode(['status' => 'correct', 'points' => 10]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO solved_questions (user_id, question_id) VALUES (?, ?)");
            $stmt->execute([$user_id, $question_id]);
            echo json_encode(['status' => 'incorrect']);
        }

    } else {
        echo json_encode(['status' => 'already_solved']);
    }
}
?>
