CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    score INT DEFAULT 0,
    avatar VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS solved_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    question_id INT NOT NULL,
    solved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS questions (
    id INT PRIMARY KEY,
    question_text TEXT NOT NULL,
    option1 VARCHAR(255) NOT NULL,
    option2 VARCHAR(255) NOT NULL
);

INSERT INTO questions (id, question_text, option1, option2) VALUES
(1, 'Which one is a prime number greater than 10?', '11', '13'),
(2, 'Which one is a programming language created in the 1990s?', 'Java', 'Python'),
(3, 'Which one is a planet in our solar system?', 'Mars', 'Jupiter'),
(4, 'Which one is an even number?', '8', '14'),
(5, 'Which one is a data structure?', 'Stack', 'Queue'),
(6, 'Which one is a metal?', 'Gold', 'Silver')
ON DUPLICATE KEY UPDATE question_text=VALUES(question_text);
