<?php
require_once 'config.php';
if (isLoggedIn()) redirect('index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Quiz App</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>

    <main class="container">
        <div class="auth-container">
            <h2 style="text-align:center;">Login</h2>
            <p style="text-align:center; font-size:0.9rem; color:#666; margin-bottom:2rem;">Please sign in to continue.</p>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="error-msg"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="success-msg"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <form action="auth.php" method="POST" class="auth-form">
                <input type="hidden" name="action" value="login">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter your username" required>
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required>
                <button type="submit" class="auth-submit">Sign In</button>
            </form>
            <p style="text-align:center; margin-top:2rem; font-size:0.9rem;">
                Don't have an account? <a href="register.php" style="color:var(--accent-color); font-weight:600;">Sign up here</a>
            </p>
        </div>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
