<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$stmt = $pdo->query("SELECT * FROM questions ORDER BY id ASC");
$all_questions = $stmt->fetchAll();

if (!isset($_SESSION['correct_options'])) {
    $_SESSION['correct_options'] = [];
    foreach ($all_questions as $q) {
        $_SESSION['correct_options'][$q['id']] = (rand(0, 1) === 0) ? $q['option1'] : $q['option2'];
    }
}

$stmt = $pdo->prepare("SELECT question_id FROM solved_questions WHERE user_id = ?");
$stmt->execute([$user_id]);
$solved_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

$current_question = null;
foreach ($all_questions as $q) {
    if (!in_array($q['id'], $solved_ids)) {
        $current_question = $q;
        break;
    }
}

$quiz_complete = ($current_question === null && count($all_questions) > 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz App</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>
    <main class="container">
        <header class="page-header">
            <h1>Quiz</h1>
            <p>Welcome, <?php echo htmlspecialchars($user['username']); ?>! Your current score is <span id="user-score"><?php echo $user['score']; ?></span> points.</p>
        </header>

        <section class="quiz-container">
            <?php if ($quiz_complete): ?>
                <div class="completion-card">
                    <h2>Congratulations!</h2>
                    <p>You have completed all available questions.</p>
                    <a href="leaderboard.php" class="auth-submit" style="display:inline-block; margin-top:2rem; text-decoration:none;">View Leaderboard</a>
                </div>
            <?php elseif ($current_question): ?>
                <div class="quiz-card" id="q-<?php echo $current_question['id']; ?>">
                    <div class="card-header">
                        Question #<?php echo $current_question['id']; ?>
                    </div>
                    <p class="question-text"><?php echo htmlspecialchars($current_question['question_text']); ?></p>
                    <div class="options">
                        <?php 
                        $opts = [$current_question['option1'], $current_question['option2']];
                        shuffle($opts); 
                        foreach($opts as $opt): ?>
                            <button class="option-btn" onclick="submitAnswer(<?php echo $current_question['id']; ?>, '<?php echo addslashes($opt); ?>')"><?php echo htmlspecialchars($opt); ?></button>
                        <?php endforeach; ?>
                    </div>
                    <div class="feedback" id="feedback-<?php echo $current_question['id']; ?>"></div>
                </div>
            <?php else: ?>
                <p>No questions available.</p>
            <?php endif; ?>
        </section>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        function submitAnswer(qId, answer) {
            const feedback = document.getElementById(`feedback-${qId}`);
            feedback.innerHTML = '<span class="loading">Evaluating response...</span>';
            
            const formData = new FormData();
            formData.append('question_id', qId);
            formData.append('answer', answer);

            fetch('submit.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const btns = document.querySelectorAll('.option-btn');
                btns.forEach(b => b.disabled = true);

                if (data.status === 'correct') {
                    feedback.innerHTML = '<span class="success">Correct. Advancing inquiry...</span>';
                    const scoreEl = document.getElementById('user-score');
                    scoreEl.innerText = parseInt(scoreEl.innerText) + data.points;
                } else if (data.status === 'already_solved') {
                    feedback.innerHTML = '<span class="info">Inquiry previously archived. Advancing...</span>';
                } else {
                    feedback.innerHTML = '<span class="error">Incorrect. Inquiry archived. Advancing...</span>';
                }

                setTimeout(() => {
                    location.reload();
                }, 1200);
            });
        }
    </script>
</body>
</html>
