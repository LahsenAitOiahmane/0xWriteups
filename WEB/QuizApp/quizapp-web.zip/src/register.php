<?php
require_once 'config.php';
if (isLoggedIn()) redirect('index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Quiz App</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <?php include 'header.php'; ?>
    <main class="container">
        <div class="auth-container">
            <h2 style="text-align:center;">Register</h2>
            <p style="text-align:center; font-size:0.9rem; color:#666; margin-bottom:2rem;">Create a new account to start the quiz.</p>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="error-msg"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <form action="auth.php" method="POST" class="auth-form">
                <input type="hidden" name="action" value="register">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter a username" required>
                <label>Password</label>
                <input type="password" name="password" placeholder="Create a password" required>
                <button type="submit" class="auth-submit">Register</button>
            </form>
            <p style="text-align:center; margin-top:2rem; font-size:0.9rem;">
                Already have an account? <a href="login.php" style="color:var(--accent-color); font-weight:600;">Login here</a>
            </p>
        </div>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
