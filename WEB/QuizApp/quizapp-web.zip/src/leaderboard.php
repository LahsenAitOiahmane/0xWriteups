<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$stmt = $pdo->query("SELECT username, score, avatar FROM users ORDER BY score DESC LIMIT 10");
$top_users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leaderboard - Quiz App</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        .leaderboard-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .leaderboard-table th, .leaderboard-table td {
            padding: 1.2rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .leaderboard-table th {
            background: #f8f9fa;
            color: var(--primary-color);
            text-transform: uppercase;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .avatar-img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent-color);
            vertical-align: middle;
            margin-right: 12px;
        }
        .rank {
            font-weight: bold;
            color: var(--accent-color);
            width: 60px;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <main class="container">
        <header class="page-header">
            <h1>Leaderboard</h1>
            <p>Our top performers and their current scores.</p>
        </header>

        <table class="leaderboard-table">
            <thead>
                <tr>
                    <th class="rank">#</th>
                    <th>User</th>
                    <th>Score</th>
                </tr>
            </thead>
            <tbody>
                <?php $rank = 1; foreach ($top_users as $user): ?>
                    <tr>
                        <td class="rank"><?php echo $rank++; ?></td>
                        <td>
                            <img src="uploads/<?php echo htmlspecialchars($user['avatar']); ?>" onerror="this.src='default.png'" class="avatar-img">
                            <?php echo htmlspecialchars($user['username']); ?>
                        </td>
                        <td style="font-weight:600;"><?php echo $user['score']; ?> pts</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
