#!/bin/bash

docker stop quizapp-ramadan26 2>/dev/null || true
docker rm quizapp-ramadan26 2>/dev/null || true

docker build -t quizapp-ramadan26 .
if [ "$1" == "local" ]; then
    docker run -p 3000:80 quizapp-ramadan26
fi
