#!/bin/bash

chown -R mysql:mysql /var/lib/mysql
mysql_install_db --user=mysql --datadir=/var/lib/mysql > /dev/null

/usr/bin/mariadbd-safe --datadir='/var/lib/mysql' &

while ! mysqladmin ping -h localhost --silent; do
    sleep 1
done

mysql -e "CREATE DATABASE IF NOT EXISTS quiz_db;"
mysql -e "CREATE USER IF NOT EXISTS 'quiz_user'@'%' IDENTIFIED BY 'quiz_pass';"
mysql -e "GRANT ALL PRIVILEGES ON quiz_db.* TO 'quiz_user'@'%';"
mysql -e "FLUSH PRIVILEGES;"

if [ -f /var/www/html/schema.sql ]; then
    mysql quiz_db < /var/www/html/schema.sql
fi

chown -R www-data:www-data /var/www/html/

if [ -f /var/www/html/schema.sql ]; then
    mysql quiz_db < /var/www/html/schema.sql
fi

mysqladmin -u root password 'root' shutdown

exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
