package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"os/exec"

	pb "monitor/proto"

	"google.golang.org/grpc"
)

type server struct {
	pb.UnimplementedHealthCheckServer
}

func (s *server) CheckHealth(ctx context.Context, in *pb.HealthRequest) (*pb.HealthResponse, error) {
	ip := in.GetIp()
	log.Printf("Received health check request for: %s", ip)

	cmdStr := fmt.Sprintf("ping -c 1 %s", ip)
	out, err := exec.Command("sh", "-c", cmdStr).CombinedOutput()

	result := string(out)
	status := "Success"
	if err != nil {
		status = "Error"
		result = fmt.Sprintf("Error: %v\nOutput: %s", err, result)
	}

	return &pb.HealthResponse{
		Status: status,
		Result: result,
	}, nil
}

func main() {
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterHealthCheckServer(s, &server{})
	log.Printf("Academic Health gRPC server listening at %v", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
